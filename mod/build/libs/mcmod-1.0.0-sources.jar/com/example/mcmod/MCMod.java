package com.example.mcmod;

import com.example.mcmod.entity.ModEntities;
import com.example.mcmod.items.CustomItem;
import com.example.mcmod.RitualHandler;
import com.example.mcmod.HauntingManager;
import com.example.mcmod.command.AskCommand;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3620;
import net.minecraft.class_7706;
import net.minecraft.class_7923;

public class MCMod implements ModInitializer {
    public static final String MOD_ID = "mcmod";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    // Custom item
    public static final class_1792 CUSTOM_ITEM = new CustomItem(new class_1792.class_1793());

    // Custom block
    public static final class_2248 CUSTOM_BLOCK = new class_2248(class_2248.Settings.method_9637().method_31710(class_3620.field_16005).method_9632(4.0f).method_29292());

    // Block item
    public static final class_1747 CUSTOM_BLOCK_ITEM = new class_1747(CUSTOM_BLOCK, new class_1792.class_1793());

    @Override
    public void onInitialize() {
        LOGGER.info("Initializing MC Mod!");

        // Register /ask command
        net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            AskCommand.register(dispatcher);
        });

        // Register custom entities
        ModEntities.register();

        // Register the custom item
        class_2378.method_10230(class_7923.field_41178, class_2960.method_43902(MOD_ID, "custom_item"), CUSTOM_ITEM);
        
        // Register the custom block
        class_2378.method_10230(class_7923.field_41175, class_2960.method_43902(MOD_ID, "custom_block"), CUSTOM_BLOCK);
        class_2378.method_10230(class_7923.field_41178, class_2960.method_43902(MOD_ID, "custom_block"), CUSTOM_BLOCK_ITEM);
        
        // Add items to the vanilla Building Blocks creative tab
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40195).register(entries -> {
            entries.method_45421(CUSTOM_ITEM);
            entries.method_45421(CUSTOM_BLOCK_ITEM);
        });

        // Register ritual handler
        RitualHandler.register();

        // Register server tick event for haunting
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            HauntingManager.tick(server);
        });

        LOGGER.info("MC Mod initialized successfully!");
    }
} 