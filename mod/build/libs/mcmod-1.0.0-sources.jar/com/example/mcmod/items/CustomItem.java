package com.example.mcmod.items;

import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public class CustomItem extends class_1792 {
    public CustomItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        class_1799 itemStack = user.method_5998(hand);
        
        if (!world.field_9236) {
            // Teleport the player 10 blocks in the direction they're looking
            class_2338 pos = user.method_24515();
            class_2338 targetPos = pos.method_10081(user.method_5735().method_10163().method_35862(10));
            
            // Make sure the target position is safe (not inside blocks)
            while (world.method_8320(targetPos).method_26212(world, targetPos) && 
                   targetPos.method_10264() < world.method_8624(net.minecraft.class_2902.class_2903.field_13202, targetPos.method_10263(), targetPos.method_10260())) {
                targetPos = targetPos.method_10084();
            }
            
            if (user instanceof class_3222 serverPlayer) {
                serverPlayer.method_6082(targetPos.method_10263() + 0.5, targetPos.method_10264(), targetPos.method_10260() + 0.5, true);
                user.method_7353(class_2561.method_43470("§bYou have been teleported!"), false);
            }
        }
        
        user.method_6122(hand, itemStack);
        return class_1271.method_29237(itemStack, world.field_9236);
    }
} 