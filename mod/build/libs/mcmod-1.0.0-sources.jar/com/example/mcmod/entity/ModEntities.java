package com.example.mcmod.entity;

import com.example.mcmod.MCMod;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class ModEntities {
    public static class_1299<DoppelgangerEntity> DOPPELGANGER;

    public static final class_5321<class_1299<?>> DOPPELGANGER_KEY =
        class_5321.method_29179(class_7924.field_41266, class_2960.method_43902(MCMod.MOD_ID, "doppelganger"));

    public static void register() {
        DOPPELGANGER = class_2378.method_10230(
            class_7923.field_41177,
            class_2960.method_43902(MCMod.MOD_ID, "doppelganger"),
            class_1299.class_1300.method_5903(DoppelgangerEntity::new, class_1311.field_6302)
                .method_5905("doppelganger")
        );
        
        // Register default attributes for the doppelganger
        FabricDefaultAttributeRegistry.register(DOPPELGANGER, DoppelgangerEntity.method_26828());
    }
} 