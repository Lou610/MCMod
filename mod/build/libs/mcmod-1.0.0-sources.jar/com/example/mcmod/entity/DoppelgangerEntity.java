package com.example.mcmod.entity;

import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1361;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_3532;
import net.minecraft.class_5132;
import net.minecraft.class_5134;

public class DoppelgangerEntity extends class_1308 {
    private String skinProfileName;
    private class_1657 targetPlayer;
    private long nextAppearTick = 0L;

    public DoppelgangerEntity(class_1299<? extends class_1308> type, class_1937 world) {
        super(type, world);
    }

    public static class_5132.class_5133 method_26828() {
        return class_1308.method_26828()
            .method_26868(class_5134.field_23716, 20.0)
            .method_26868(class_5134.field_23719, 0.3)
            .method_26868(class_5134.field_23721, 3.0)
            .method_26868(class_5134.field_23717, 16.0);
    }

    public void setSkinProfileName(String name) {
        this.skinProfileName = name;
    }

    public String getSkinProfileName() {
        return skinProfileName;
    }

    public void setTargetPlayer(class_1657 player) {
        this.targetPlayer = player;
    }

    public void setNextAppearTick(long tick) {
        this.nextAppearTick = tick;
    }

    public long getNextAppearTick() {
        return nextAppearTick;
    }

    @Override
    protected void method_5959() {
        // Make the doppelganger look at the target player
        this.field_6201.method_6277(1, new class_1361(this, class_1657.class, 8.0f));
        // No vanilla wander goal, using custom walk in tick()
    }

    @Override
    public void method_5773() {
        super.method_5773();
        // Make the doppelganger face the target player when they're close
        if (targetPlayer != null && targetPlayer.method_5805()) {
            class_243 toPlayer = targetPlayer.method_19538().method_1020(this.method_19538()).method_1029();
            this.method_36456((float) Math.toDegrees(Math.atan2(-toPlayer.field_1352, toPlayer.field_1350)));
        }
        // Custom random walk: only if not being looked at
        if (this.method_37908() != null && !this.method_37908().field_9236 && this.field_6012 % 20 == 0) { // every second
            if (targetPlayer != null && !isPlayerLookingAtMe(targetPlayer)) {
                double angle = this.field_5974.method_43058() * 2 * Math.PI;
                double distance = 2.0 + this.field_5974.method_43058() * 3.0; // 2-5 blocks
                double dx = class_3532.method_15362((float) angle) * distance;
                double dz = class_3532.method_15374((float) angle) * distance;
                double newX = this.method_23317() + dx;
                double newZ = this.method_23321() + dz;
                double newY = this.method_23318();
                class_2338 newPos = class_2338.method_49637(newX, newY, newZ);
                if (this.method_37908().method_22347(newPos) && this.method_37908().method_22347(newPos.method_10084())) {
                    this.method_5942().method_6337(newX, newY, newZ, 1.0);
                }
            }
        }
    }

    private boolean isPlayerLookingAtMe(class_1657 player) {
        class_243 playerLook = player.method_5828(1.0f);
        class_243 toEntity = this.method_19538().method_1020(player.method_19538()).method_1029();
        double dot = playerLook.method_1026(toEntity);
        double angle = Math.acos(dot) * (180.0 / Math.PI);
        return angle < 30.0;
    }

    @Override
    public void method_5652(class_2487 nbt) {
        super.method_5652(nbt);
        if (skinProfileName != null) nbt.method_10582("SkinProfileName", skinProfileName);
        nbt.method_10544("NextAppearTick", nextAppearTick);
    }

    @Override
    public void method_5749(class_2487 nbt) {
        super.method_5749(nbt);
        if (nbt.method_10545("SkinProfileName")) {
            skinProfileName = nbt.method_10558("SkinProfileName");
        }
        if (nbt.method_10545("NextAppearTick")) {
            nextAppearTick = nbt.method_10537("NextAppearTick");
        }
    }

    // TODO: Custom rendering to use the haunted player's skin
    // TODO: Only visible to the haunted player
} 