package com.example.mcmod.network;

import com.example.mcmod.entity.ModEntities;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import com.example.mcmod.entity.DoppelgangerEntity;
import com.example.mcmod.MCMod;

public class HauntPackets {
    // TODO: Implement proper networking when we have the correct API
    public static void sendSpawnDoppelganger(class_3222 player, class_243 pos, String skinName) {
        class_3218 world = (class_3218) player.method_37908();
        if (world != null) {
            DoppelgangerEntity entity = new DoppelgangerEntity(ModEntities.DOPPELGANGER, world);
            entity.method_33574(pos);
            entity.setSkinProfileName(skinName);
            world.method_8649(entity);
        }
    }

    public static void sendDespawnDoppelganger(class_3222 player) {
        // For now, just remove entities directly on the server
        if (player.method_37908() != null) {
            // Use a simple approach to find and remove Doppelganger entities
            // This is a workaround since we don't have the exact API method
            try {
                // Try to access entities through reflection if needed
                java.lang.reflect.Field entitiesField = player.method_37908().getClass().getDeclaredField("entities");
                entitiesField.setAccessible(true);
                java.util.Collection<class_1297> entities = (java.util.Collection<class_1297>) entitiesField.get(player.method_37908());
                if (entities != null) {
                    entities.removeIf(entity -> entity instanceof DoppelgangerEntity);
                }
            } catch (Exception e) {
                // Fallback: just log that we can't remove entities
                MCMod.LOGGER.warn("Could not remove Doppelganger entities: " + e.getMessage());
            }
        }
    }

    public static void registerClientHandlers() {
        // TODO: Implement client-side networking when we have the correct API
    }
} 