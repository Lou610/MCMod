package com.example.mcmod;

import com.example.mcmod.entity.ModEntities;
import com.example.mcmod.entity.DoppelgangerEntity;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_5602;
import net.minecraft.class_591;
import net.minecraft.class_742;
import net.minecraft.class_927;

public class MCModClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // Register the doppelganger renderer with player skin
        EntityRendererRegistry.register(ModEntities.DOPPELGANGER, (context) ->
            new class_927<DoppelgangerEntity, class_591<DoppelgangerEntity>>(
                context,
                new class_591<>(context.method_32167(class_5602.field_27577), false),
                0.5f
            ) {
                @Override
                public class_2960 getTexture(DoppelgangerEntity entity) {
                    // Get the skin profile name from the doppelganger
                    String skinProfileName = entity.getSkinProfileName();
                    if (skinProfileName != null && !skinProfileName.isEmpty()) {
                        // Try to find the player with this name
                        class_310 client = class_310.method_1551();
                        if (client.field_1687 != null) {
                            for (var player : client.field_1687.method_18456()) {
                                if (player.method_5477().getString().equals(skinProfileName)) {
                                    // Use the player's skin texture
                                    return player.method_52814().comp_1626();
                                }
                            }
                        }
                    }
                    // Fallback to default Steve texture
                    return new class_2960("minecraft", "textures/entity/steve.png");
                }
            }
        );
    }
} 