package com.example.mcmod;

import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.class_1263;
import net.minecraft.class_1269;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2595;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.server.MinecraftServer;
import java.util.List;

public class RitualHandler {
    public static void register() {
        UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
            if (world.field_9236) return class_1269.field_5811;

            class_2338 pos = hitResult.method_17777();
            class_2248 block = world.method_8320(pos).method_26204();
            class_2350 facing = player.method_5735();

            // Check if player is placing a candle on a netherrack block
            if (block == class_2246.field_10515 && isCandle(player.method_6047().method_7909())) {
                // Chest must be to the right of the netherrack block (relative to player facing)
                class_2350 right = facing.method_10170();
                class_2338 chestPos = pos.method_10093(right);
                class_2248 chestBlock = world.method_8320(chestPos).method_26204();
                if (chestBlock != class_2246.field_10034) return class_1269.field_5811;

                // Check chest for paper with a player's name
                class_2586 be = world.method_8321(chestPos);
                if (!(be instanceof class_2595 chest)) return class_1269.field_5811;
                
                // Use the inventory interface
                class_1263 inv = chest;
                for (int i = 0; i < inv.method_5439(); i++) {
                    class_1799 stack = inv.method_5438(i);
                    if (stack.method_7909() == class_1802.field_8407 && !stack.method_7964().equals(stack.method_7909().method_7864(stack))) {
                        String targetName = stack.method_7964().getString();
                        // Try to find the player by name
                        MinecraftServer server = player.method_5682();
                        if (server != null) {
                            class_3222 target = server.method_3760().method_14566(targetName);
                            if (target != null) {
                                // Ritual complete! Consume the paper and trigger haunting
                                stack.method_7934(1);
                                MCMod.LOGGER.info("Ritual complete! Haunting triggered for {} by {}", targetName, player.method_5477().getString());
                                player.method_7353(class_2561.method_43470("§4The ritual is complete. The haunting begins..."), false);
                                target.method_7353(class_2561.method_43470("§8You feel a chill run down your spine..."), false);
                                HauntingManager.startHaunting(target);
                                // Play ticking clock sound for all players
                                for (class_3222 p : player.method_5682().method_3760().method_14571()) {
                                    p.method_37908().method_8396(null, p.method_24515(), class_3414.method_47908(class_2960.method_43902("mcmod", "haunt_ritual")), class_3419.field_15256, 1.0f, 1.0f);
                                }
                                return class_1269.field_5812;
                            }
                        }
                    }
                }
            }
            return class_1269.field_5811;
        });
    }

    private static boolean isCandle(net.minecraft.class_1792 item) {
        // Check for all vanilla candle types
        return item == net.minecraft.class_1802.field_27024
            || item == net.minecraft.class_1802.field_27025
            || item == net.minecraft.class_1802.field_27026
            || item == net.minecraft.class_1802.field_27027
            || item == net.minecraft.class_1802.field_27028
            || item == net.minecraft.class_1802.field_27029
            || item == net.minecraft.class_1802.field_27052
            || item == net.minecraft.class_1802.field_27053
            || item == net.minecraft.class_1802.field_27054
            || item == net.minecraft.class_1802.field_27055
            || item == net.minecraft.class_1802.field_27056
            || item == net.minecraft.class_1802.field_27057
            || item == net.minecraft.class_1802.field_27058
            || item == net.minecraft.class_1802.field_27059
            || item == net.minecraft.class_1802.field_27060
            || item == net.minecraft.class_1802.field_27061
            || item == net.minecraft.class_1802.field_27062;
    }
} 