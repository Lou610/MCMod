package com.example.mcmod.command;

import com.example.mcmod.HauntingManager;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.Command;
import com.mojang.brigadier.arguments.StringArgumentType;

public class AskCommand {
    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(class_2170.method_9247("ask")
            .then(class_2170.method_9244("question", StringArgumentType.greedyString())
                .executes(ctx -> {
                    class_2168 source = ctx.getSource();
                    if (!(source.method_9228() instanceof class_3222 player)) {
                        source.method_9213(class_2561.method_43470("Only players can use this command."));
                        return Command.SINGLE_SUCCESS;
                    }
                    if (!HauntingManager.isHaunted(player)) {
                        player.method_7353(class_2561.method_43470("You feel nothing but silence..."), false);
                        return Command.SINGLE_SUCCESS;
                    }
                    String question = StringArgumentType.getString(ctx, "question").trim().toLowerCase().replaceAll("[^a-z0-9 ]", "");
                    player.method_7353(class_2561.method_43470("§7You ask: '" + StringArgumentType.getString(ctx, "question") + "'"), false);
                    String answer;
                    switch (question) {
                        case "who are you":
                            answer = "I am MeeperCreeper";
                            break;
                        case "where are you":
                            answer = "Where I can see you but you cannot see me...";
                            break;
                        case "what are you":
                            answer = "I am you...";
                            break;
                        default:
                            answer = "The Doppelgänger whispers something you cannot understand...";
                            break;
                    }
                    player.method_7353(class_2561.method_43470("§8The Doppelgänger whispers: '" + answer + "'"), false);
                    return Command.SINGLE_SUCCESS;
                })
            )
        );
    }
} 