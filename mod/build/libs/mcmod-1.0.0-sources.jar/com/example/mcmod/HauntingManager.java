package com.example.mcmod;

import com.example.mcmod.entity.DoppelgangerEntity;
import com.example.mcmod.entity.ModEntities;
import com.example.mcmod.network.HauntPackets;
import com.mojang.authlib.GameProfile;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2323;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2625;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_4208;
import net.minecraft.server.MinecraftServer;
import java.lang.reflect.Field;
import java.util.UUID;
import java.util.WeakHashMap;
import java.util.Random;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import java.lang.reflect.Method;

public class HauntingManager {
    private static UUID hauntedPlayerId = null;
    private static final WeakHashMap<class_3222, DoppelgangerEntity> doppelgangers = new WeakHashMap<>();
    private static final Random random = new Random();
    private static final HashMap<UUID, Long> hauntingStartTime = new HashMap<>();
    private static final HashMap<UUID, Boolean> entityCanEnterHome = new HashMap<>();
    private static final HashMap<UUID, Long> lastKnockTime = new HashMap<>();
    private static final HashMap<UUID, Boolean> basementBuilt = new HashMap<>();
    private static final HashMap<UUID, Long> lastDamageTime = new HashMap<>();
    private static final HashMap<UUID, Long> nextDoppelgangerAppearTime = new HashMap<>();

    // Utility method to get player's bed/respawn position using reflection
    private static class_2338 getPlayerBedPosition(class_3222 player) {
        try {
            // Try common field names for bed/respawn position
            String[] possibleFieldNames = {
                "spawnPointPosition", "bedPosition", "respawnPosition", "spawnPoint",
                "bedLocation", "respawnLocation", "spawnLocation"
            };
            
            Class<?> playerClass = player.getClass();
            
            // First try ServerPlayerEntity
            for (String fieldName : possibleFieldNames) {
                try {
                    Field field = playerClass.getDeclaredField(fieldName);
                    field.setAccessible(true);
                    Object value = field.get(player);
                    if (value instanceof class_2338) {
                        return (class_2338) value;
                    } else if (value instanceof class_4208) {
                        // Try to get BlockPos from GlobalPos using reflection
                        try {
                            Field posField = class_4208.class.getDeclaredField("pos");
                            posField.setAccessible(true);
                            return (class_2338) posField.get(value);
                        } catch (Exception e) {
                            // Continue to next field
                        }
                    }
                } catch (NoSuchFieldException | IllegalAccessException e) {
                    // Continue to next field
                }
            }
            
            // Try parent class (PlayerEntity)
            Class<?> parentClass = playerClass.getSuperclass();
            if (parentClass != null) {
                for (String fieldName : possibleFieldNames) {
                    try {
                        Field field = parentClass.getDeclaredField(fieldName);
                        field.setAccessible(true);
                        Object value = field.get(player);
                        if (value instanceof class_2338) {
                            return (class_2338) value;
                        } else if (value instanceof class_4208) {
                            // Try to get BlockPos from GlobalPos using reflection
                            try {
                                Field posField = class_4208.class.getDeclaredField("pos");
                                posField.setAccessible(true);
                                return (class_2338) posField.get(value);
                            } catch (Exception e) {
                                // Continue to next field
                            }
                        }
                    } catch (NoSuchFieldException | IllegalAccessException e) {
                        // Continue to next field
                    }
                }
            }
            
        } catch (Exception e) {
            MCMod.LOGGER.warn("Failed to get bed position for player: " + e.getMessage());
        }
        
        // Fallback: return null if no bed position found
        return null;
    }

    public static void startHaunting(class_3222 player) {
        hauntedPlayerId = player.method_5667();
        hauntingStartTime.put(hauntedPlayerId, player.method_37908().method_8510());
    }

    public static void stopHaunting() {
        hauntedPlayerId = null;
        doppelgangers.keySet().forEach(player -> HauntPackets.sendDespawnDoppelganger(player));
        doppelgangers.clear();
        hauntingStartTime.clear();
    }

    public static boolean isHaunted(class_3222 player) {
        return hauntedPlayerId != null && hauntedPlayerId.equals(player.method_5667());
    }

    public static UUID getHauntedPlayerId() {
        return hauntedPlayerId;
    }

    public static long getHauntingDuration(class_3222 player) {
        if (!isHaunted(player)) return 0;
        long start = hauntingStartTime.getOrDefault(player.method_5667(), player.method_37908().method_8510());
        return player.method_37908().method_8510() - start;
    }

    public static boolean isPlayerAtHome(class_3222 player) {
        class_2338 bed = getPlayerBedPosition(player);
        if (bed == null) return false;
        class_1937 world = player.method_37908();
        double dist = player.method_19538().method_1022(class_243.method_24953(bed));
        return dist < 8.0;
    }

    // Call this from a server tick event
    public static void tick(MinecraftServer server) {
        if (hauntedPlayerId == null) return;
        class_3222 player = getHauntedPlayer(server);
        if (player == null || !player.method_5805()) {
            stopHaunting();
            return;
        }
        long duration = getHauntingDuration(player);
        boolean atHome = isPlayerAtHome(player);
        boolean canEnter = entityCanEnterHome.getOrDefault(player.method_5667(), false);
        
        // For testing: immediately allow doppelganger to enter after ritual
        if (!canEnter && duration > 100) { // After 5 seconds instead of 2-4 days
            entityCanEnterHome.put(player.method_5667(), true);
            player.method_7353(class_2561.method_43470("§8The entity can now enter your home..."), false);
        }
        
        // Knocking phase: after 2-3 days (24000 ticks per day) - DISABLED FOR TESTING
        if (!canEnter && duration > 2 * 24000 && duration < 4 * 24000 && atHome) {
            long now = player.method_37908().method_8510();
            long lastKnock = lastKnockTime.getOrDefault(player.method_5667(), 0L);
            if (now - lastKnock > 100) { // Knock every 5 seconds (100 ticks)
                class_2338 door = findNearestDoor(player);
                if (door != null) {
                    // Play knocking sound at the door
                    player.method_37908().method_8396(null, door, class_3414.method_47908(class_2960.method_43902("mcmod", "haunt_knock")), class_3419.field_15245, 1.0f, 1.0f);
                }
                lastKnockTime.put(player.method_5667(), now);
            }
        }
        
        // Detect if player opens the door during knocking phase - DISABLED FOR TESTING
        if (!canEnter && atHome && player.method_6115()) {
            class_2338 door = findNearestDoor(player);
            if (door != null && isDoorOpen((class_3218) player.method_37908(), door)) {
                entityCanEnterHome.put(player.method_5667(), true);
                // Play demon laugh sound for the haunted player
                player.method_37908().method_8396(null, player.method_24515(), class_3414.method_47908(class_2960.method_43902("mcmod", "haunt_laugh")), class_3419.field_15248, 1.0f, 1.0f);
            }
        }
        
        // Doppelganger peripheral vision logic
        if (entityCanEnterHome.getOrDefault(player.method_5667(), false)) {
            DoppelgangerEntity doppelganger = doppelgangers.get(player);
            
            // Check if we need to respawn the doppelganger after cooldown
            if (doppelganger == null) {
                // Check if there's a cooldown timer for this player
                Long nextAppearTime = nextDoppelgangerAppearTime.get(player.method_5667());
                if (nextAppearTime != null && nextAppearTime > 0) {
                    long currentTime = player.method_37908().method_8510();
                    if (currentTime >= nextAppearTime) {
                        // Time to respawn!
                        nextDoppelgangerAppearTime.remove(player.method_5667());
                        player.method_7353(class_2561.method_43470("§8You feel a presence watching you again..."), false);
                    } else {
                        // Still in cooldown, don't spawn yet
                        return;
                    }
                }
                
                // Spawn doppelganger if it doesn't exist
                if (doppelganger == null) {
                    class_2338 spawnPos = getPeripheralSpawnPos(player);
                    if (spawnPos != null) {
                        GameProfile profile = player.method_7334();
                        doppelganger = new DoppelgangerEntity(ModEntities.DOPPELGANGER, player.method_37908());
                        doppelganger.method_33574(class_243.method_24953(spawnPos));
                        doppelganger.setSkinProfileName(profile.getName());
                        doppelganger.setTargetPlayer(player);
                        player.method_37908().method_8649(doppelganger);
                        doppelgangers.put(player, doppelganger);
                        // Play ghostly whispers sound for the haunted player
                        player.method_37908().method_8396(null, player.method_24515(), class_3414.method_47908(class_2960.method_43902("mcmod", "haunt_whisper")), class_3419.field_15248, 1.0f, 1.0f);
                        player.method_7353(class_2561.method_43470("§8A doppelganger has appeared in your peripheral vision..."), false);
                        MCMod.LOGGER.info("Doppelganger spawned for player {} at position {}", player.method_5477().getString(), spawnPos);
                    } else {
                        player.method_7353(class_2561.method_43470("§8Failed to find spawn position for doppelganger"), false);
                        MCMod.LOGGER.warn("Could not find peripheral spawn position for player {}", player.method_5477().getString());
                    }
                }
            } else {
                // Handle doppelganger movement and damage logic
                handleDoppelgangerBehavior(player, doppelganger);
            }
            
            // Secret basement construction and sign placement
            if (shouldBuildBasement(duration)) {
                buildSecretBasement(player);
                placeLureSigns(player);
                checkBasementFinale(player);
            }
        } else {
            // Debug message for testing
            if (duration % 200 == 0) { // Every 10 seconds
                player.method_7353(class_2561.method_43470("§7Debug: Haunting duration: " + duration + " ticks, Can enter: " + canEnter), false);
            }
        }
    }

    private static class_3222 getHauntedPlayer(MinecraftServer server) {
        if (hauntedPlayerId == null) return null;
        for (class_3222 player : server.method_3760().method_14571()) {
            if (player.method_5667().equals(hauntedPlayerId)) return player;
        }
        return null;
    }

    private static class_2338 getPeripheralSpawnPos(class_3222 player) {
        class_243 playerPos = player.method_19538();
        class_243 look = player.method_5828(1.0f);
        // Try up to 10 times to find a valid peripheral position
        for (int i = 0; i < 10; i++) {
            double angle = Math.toRadians(60 + random.nextInt(60)); // 60-120 degrees off center
            if (random.nextBoolean()) angle = -angle;
            double radius = 6 + random.nextInt(5); // 6-10 blocks away
            double dx = look.field_1352 * Math.cos(angle) - look.field_1350 * Math.sin(angle);
            double dz = look.field_1352 * Math.sin(angle) + look.field_1350 * Math.cos(angle);
            double x = playerPos.field_1352 + dx * radius;
            double z = playerPos.field_1350 + dz * radius;
            int y = player.method_31478();
            class_2338 pos = class_2338.method_49637(x, y, z);
            // Check for air block to spawn in
            if (player.method_37908().method_22347(pos) && player.method_37908().method_22347(pos.method_10084())) {
                return pos;
            }
        }
        return null;
    }

    private static boolean isLookingAt(class_3222 player, DoppelgangerEntity entity, double thresholdDegrees) {
        class_243 playerLook = player.method_5828(1.0f);
        class_243 toEntity = entity.method_19538().method_1020(player.method_19538()).method_1029();
        double dot = playerLook.method_1026(toEntity);
        double angle = Math.acos(dot) * (180.0 / Math.PI);
        return angle < thresholdDegrees;
    }

    private static class_2338 findNearestDoor(class_3222 player) {
        class_2338 bed = getPlayerBedPosition(player);
        if (bed == null) return null;
        class_3218 world = (class_3218) player.method_37908();
        class_2338 nearest = null;
        double minDist = Double.MAX_VALUE;
        for (class_2338 pos : class_2338.method_25996(bed, 8, 4, 8)) {
            class_2248 block = world.method_8320(pos).method_26204();
            if (block instanceof class_2323) {
                double dist = player.method_19538().method_1022(class_243.method_24953(pos));
                if (dist < minDist) {
                    minDist = dist;
                    nearest = pos;
                }
            }
        }
        return nearest;
    }

    private static boolean isDoorOpen(class_3218 world, class_2338 pos) {
        class_2248 block = world.method_8320(pos).method_26204();
        if (block instanceof class_2323) {
            return world.method_8320(pos).method_11654(class_2323.field_10945);
        }
        return false;
    }

    private static class_2338 getHomeSpawnPos(class_3222 player) {
        class_2338 bed = getPlayerBedPosition(player);
        if (bed == null) return null;
        class_3218 world = (class_3218) player.method_37908();
        // Try up to 10 times to find a valid spawn position in the home (within 6 blocks of bed)
        for (int i = 0; i < 10; i++) {
            int dx = random.nextInt(13) - 6;
            int dz = random.nextInt(13) - 6;
            class_2338 pos = bed.method_10069(dx, 0, dz);
            if (world.method_22347(pos) && world.method_22347(pos.method_10084())) {
                return pos;
            }
        }
        return null;
    }

    private static boolean shouldBuildBasement(long duration) {
        // Start building basement after 4 days of haunting
        return duration > 4 * 24000;
    }

    private static void buildSecretBasement(class_3222 player) {
        if (basementBuilt.getOrDefault(player.method_5667(), false)) return;
        class_2338 bed = getPlayerBedPosition(player);
        if (bed == null) return;
        class_3218 world = (class_3218) player.method_37908();
        // Dig stairs down from under the bed
        class_2338 stairStart = bed.method_10074();
        for (int i = 0; i < 4; i++) {
            class_2338 step = stairStart.method_10087(i).method_10079(player.method_5735(), 0);
            world.method_8501(step, class_2246.field_10124.method_9564());
        }
        // Dig out 5x5x3 room
        class_2338 roomOrigin = stairStart.method_10087(4).method_10069(-2, 0, -2);
        for (int x = 0; x < 5; x++) {
            for (int y = 0; y < 3; y++) {
                for (int z = 0; z < 5; z++) {
                    class_2338 pos = roomOrigin.method_10069(x, y, z);
                    world.method_8501(pos, class_2246.field_10124.method_9564());
                }
            }
        }
        // Place floor and walls (stone bricks)
        for (int x = 0; x < 5; x++) {
            for (int z = 0; z < 5; z++) {
                world.method_8501(roomOrigin.method_10069(x, 0, z), class_2246.field_10056.method_9564()); // floor
                world.method_8501(roomOrigin.method_10069(x, 2, z), class_2246.field_10056.method_9564()); // ceiling
            }
        }
        for (int y = 0; y < 3; y++) {
            for (int i = 0; i < 5; i++) {
                world.method_8501(roomOrigin.method_10069(0, y, i), class_2246.field_10056.method_9564());
                world.method_8501(roomOrigin.method_10069(4, y, i), class_2246.field_10056.method_9564());
                world.method_8501(roomOrigin.method_10069(i, y, 0), class_2246.field_10056.method_9564());
                world.method_8501(roomOrigin.method_10069(i, y, 4), class_2246.field_10056.method_9564());
            }
        }
        // Place a sign in the basement
        class_2338 signPos = roomOrigin.method_10069(2, 1, 2);
        world.method_8501(signPos, class_2246.field_10121.method_9564());
        class_2625 sign = (class_2625) world.method_8321(signPos);
        if (sign != null) {
            // Use reflection to set sign text since the methods are not accessible
            try {
                // Try to find and call the setText method using reflection
                Method setTextMethod = class_2625.class.getDeclaredMethod("setText", int.class, class_2561.class);
                setTextMethod.setAccessible(true);
                setTextMethod.invoke(sign, 0, class_2561.method_43470("Welcome home."));
                setTextMethod.invoke(sign, 1, class_2561.method_43470("You found me."));
                setTextMethod.invoke(sign, 2, class_2561.method_43473());
                setTextMethod.invoke(sign, 3, class_2561.method_43473());
            } catch (Exception e) {
                MCMod.LOGGER.warn("Could not set sign text: " + e.getMessage());
            }
        }
        basementBuilt.put(player.method_5667(), true);
    }

    private static void placeLureSigns(class_3222 player) {
        class_2338 bed = getPlayerBedPosition(player);
        if (bed == null) return;
        class_3218 world = (class_3218) player.method_37908();
        // Place a sign near the bed
        class_2338 signPos = bed.method_10069(1, 0, 0);
        world.method_8501(signPos, class_2246.field_10121.method_9564());
        class_2625 sign = (class_2625) world.method_8321(signPos);
        if (sign != null) {
            // Use reflection to set sign text since the methods are not accessible
            try {
                // Try to find and call the setText method using reflection
                Method setTextMethod = class_2625.class.getDeclaredMethod("setText", int.class, class_2561.class);
                setTextMethod.setAccessible(true);
                setTextMethod.invoke(sign, 0, class_2561.method_43470("Come downstairs..."));
                setTextMethod.invoke(sign, 1, class_2561.method_43470("I have something for you..."));
                setTextMethod.invoke(sign, 2, class_2561.method_43473());
                setTextMethod.invoke(sign, 3, class_2561.method_43473());
            } catch (Exception e) {
                MCMod.LOGGER.warn("Could not set sign text: " + e.getMessage());
            }
        }
    }

    private static void checkBasementFinale(class_3222 player) {
        class_2338 bed = getPlayerBedPosition(player);
        if (bed == null) return;
        class_2338 stairStart = bed.method_10074();
        class_2338 roomOrigin = stairStart.method_10087(4).method_10069(-2, 0, -2);
        class_2338 playerPos = player.method_24515();
        // If player is inside the basement room
        if (playerPos.method_10264() >= roomOrigin.method_10264() && playerPos.method_10264() < roomOrigin.method_10264() + 3 &&
            playerPos.method_10263() >= roomOrigin.method_10263() && playerPos.method_10263() < roomOrigin.method_10263() + 5 &&
            playerPos.method_10260() >= roomOrigin.method_10260() && playerPos.method_10260() < roomOrigin.method_10260() + 5) {
            // Kill the player - use a simpler approach for 1.20.4
            try {
                player.method_5643(player.method_37908().method_48963().method_48830(), Float.MAX_VALUE);
            } catch (Exception e) {
                MCMod.LOGGER.warn("Could not damage player: " + e.getMessage());
            }
            // End haunting for this player
            UUID oldId = player.method_5667();
            stopHaunting();
            // Move haunting to next player if multiplayer
            class_3222 next = pickNextHauntedPlayer(player);
            if (next != null) {
                startHaunting(next);
                next.method_7353(class_2561.method_43470("§4You feel a presence watching you..."), false);
            }
        }
    }

    private static class_3222 pickNextHauntedPlayer(class_3222 previous) {
        MinecraftServer server = previous.method_5682();
        if (server == null) return null;
        var players = server.method_3760().method_14571();
        if (players.size() <= 1) return null;
        // Pick a random player who is not the previous victim
        var eligible = players.stream().filter(p -> !p.method_5667().equals(previous.method_5667())).toList();
        if (eligible.isEmpty()) return null;
        return eligible.get(random.nextInt(eligible.size()));
    }

    private static void handleDoppelgangerBehavior(class_3222 player, DoppelgangerEntity doppelganger) {
        if (!doppelganger.method_5805()) {
            doppelgangers.remove(player);
            return;
        }
        
        class_243 playerPos = player.method_19538();
        class_243 doppelPos = doppelganger.method_19538();
        double distance = playerPos.method_1022(doppelPos);
        
        // Check if player is looking at the doppelganger
        boolean isLookingAt = isLookingAt(player, doppelganger, 30.0); // 30 degree cone
        
        // If player is looking directly at doppelganger, make it disappear for 60-512 seconds
        if (isLookingAt && distance < 15.0) {
            // Set the next appear time (60-512 seconds = 1200-10240 ticks)
            long disappearTime = 1200 + random.nextInt(10240 - 1200 + 1); // 60-512 seconds
            long nextAppearTime = player.method_37908().method_8510() + disappearTime;
            nextDoppelgangerAppearTime.put(player.method_5667(), nextAppearTime);
            
            // Remove the doppelganger from the map and kill it
            doppelgangers.remove(player);
            doppelganger.method_5650(net.minecraft.class_1297.class_5529.field_26999);
            
            // Play disappearing sound
            player.method_37908().method_8396(null, class_2338.method_49638(doppelPos), class_3414.method_47908(class_2960.method_43902("mcmod", "haunt_disappear")), class_3419.field_15248, 0.5f, 1.0f);
            
            // Send message to player
            player.method_7353(class_2561.method_43470("§8The doppelganger has vanished..."), false);
            
            MCMod.LOGGER.info("Doppelganger disappeared for player {} for {} ticks ({} seconds)", 
                player.method_5477().getString(), disappearTime, disappearTime / 20);
        }
        
        // If player looks away and doppelganger is close, damage them
        if (!isLookingAt && distance < 3.0) {
            long now = player.method_37908().method_8510();
            long lastDamage = lastDamageTime.getOrDefault(player.method_5667(), 0L);
            if (now - lastDamage > 60) { // Damage every 3 seconds
                player.method_5643(player.method_37908().method_48963().method_48830(), 2.0f);
                lastDamageTime.put(player.method_5667(), now);
                // Play damage sound
                player.method_37908().method_8396(null, player.method_24515(), class_3414.method_47908(class_2960.method_43902("mcmod", "haunt_damage")), class_3419.field_15248, 1.0f, 1.0f);
            }
        }
        
        // Occasionally move to a new peripheral position
        if (random.nextInt(200) == 0) { // 1 in 200 chance per tick
            class_2338 newPos = getPeripheralSpawnPos(player);
            if (newPos != null) {
                doppelganger.method_20620(newPos.method_10263() + 0.5, newPos.method_10264(), newPos.method_10260() + 0.5);
            }
        }
    }
} 