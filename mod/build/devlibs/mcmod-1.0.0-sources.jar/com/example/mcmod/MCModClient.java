package com.example.mcmod;

import net.fabricmc.api.ClientModInitializer;

public class MCModClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        MCMod.LOGGER.info("Initializing MCMod client-side features");
        MCMod.LOGGER.info("Doppelganger will be visible only to the haunted player");
        MCMod.LOGGER.info("Ritual completion now plays demon laugh for haunted player only");
    }
} 